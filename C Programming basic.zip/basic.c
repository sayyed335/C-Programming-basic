#include<stdio.h>  ///header file (print f,scan f "prototype")
#include<conio.h>  ///header file (clears,get ch "prototype")

void main()  ///Main function
{
    /// clear the output window
    clrscr();
    ///wait for the key press
    getch();
    ///input function
    getchar();
    gets();
    scanf();
    ///Output function
    putchar();
    puts();
    printf();
    ///loop & condition
    for, while, do, do while, if, else if, else, switch
            ///different variable
            int 1a;  ///error
float a; ///error
char _c; ///correct
double d1af25; ///correct
int for; ///error
int value,taka,store,a,d,b; ///correct
///keyword
for, while, do, do while,                                    /* this
                                                                         is
                                                                            multi line
                                                                                       comment*/

         if, else if, else, switch,
             goto,continue,break,void,return


                 ///syntax Error
                 printf()
                     puts()
                     ///logical error
                     a=a+b; >>>> a=a-b;

    ///memory location "&"

    scanf("%f",&a);
    ///Operator

    a = 5; ///assign
    a == 5;///equal
    a % 2!=0;///modulars

    a++;
    a--;///increment or decrement
    a/=5;///

    ///declare For loop
    for(i=0; i<100; i++)
    {
        statement
        statement
        statement
        statement
    }

    ///Declare While loop
    i=0;
    while(i<100)
    {
        statement
        statement
        statement
        statement
        i++;
    }
    ///Declare switch
    switch(variable)

    case 1:
    statement
    break;
case 2:
    statement
    break;
case 3:
    statement
    break;
case 4:
    statement
    break;
}
